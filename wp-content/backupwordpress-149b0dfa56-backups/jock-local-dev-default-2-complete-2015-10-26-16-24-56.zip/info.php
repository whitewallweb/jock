<?php
      phpinfo();
?>